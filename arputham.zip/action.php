<?php
session_start();
$page = "Action";
 include "timeout.php";
include "config.php";
 if(isset($_GET['status']))
{
$id=$_GET['status'];
$sql = "select * from students where id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

 while($row)
{
$status_var=$row['status'];
if($status_var=='0')
{
$status_state=1;
}
else
{
$status_state=0;
}
        

$update=mysql_query("update students set status='$status_state' where id='$id'");
if($update)
{
header("Location:billing-record.php");
}
else
{
echo mysql_error();
}
}
?>
<?php
}
?>