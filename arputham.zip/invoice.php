<?php
session_start();
$page = "Invoice";
include "timeout.php";
include "config.php";
if (($_SESSION['user_type'] != "admin"))  header("location: index.php");
$msg = "";
$msg_color = "";
$food_name="";
if (isset($_POST['submit'])) {
	$date = date('y/m/d');   
    $food_name = trim($_POST['fees_name']);
	
	  $sql = "SELECT * FROM foods WHERE trim(food_name)='$food_name'";
    $result = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($result);
   if ($count >= 1) {
        $msg = "Fees  already in use";
        $msg_color = "red";
    } else {
        $msg_color = "green";
        if($_SESSION['user_type']=="admin") {
            $msg = "Foods added successfully";
        }else{
            $msg = "Foods added successfully";
        }

        $stmt = $conn->prepare("INSERT INTO foods (food_name,created_date) VALUES (?,?)");
        $stmt->bind_param("ss",$food_name,$date);
        $stmt->execute();
		$id = $stmt->insert_id;
       
        header("location: foods.php");
    
}}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title> View Foods</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/dataTables.responsive.css">
<script src="css/dataTables.responsive.js"></script>
  <link rel="stylesheet" href="css/dataTables.responsive.scss">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

 

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<style>
    .table-bordered {
    border: 0px solid #ffffff !important;
}
    th {
    border: none !important;
}
</style>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

     <?php include "header.php"; ?>

    <?php include "menu.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  
  
  <div class="content-wrapper">
    <section class="content">
      <div class="row">

				 <div class="col-xs-12">
				
		                   <div class="login-panel panel panel-default">

						<div class="table-responsive">
                      
       <div class="box-header">
       <div class="col-12">
            <div class="text-center"> <b>JESUS SAVES </b></div>
        
        <div class="text-center"><b> ARPUTHAM AGENCIES </b></div>
             
             
           
                <div class="text-center">No.154/2, Nemilichery High Road, Postal Nagar, Chrompet, Chennai - 600 044.</div>
             <div class="text-center">Email: info@webz.com</div>
<div class="text-center">Phone: +91 9710398167, 8015161743</div>
<div class="text-center">GSTIN: 33ASKPJ3865A1ZZ</div>
       </div> 
       <br/>
       
        <div class="col-md-12">
       <div class="row">
           <div class="col-lg-12">
                                                <div class="table-responsive">
                                                    <table class="table table-bordered mb-0">
                                                         
                                                        <tbody class="border-0">
                                                            <tr>
                                                                
                                                               
                                                                <th colspan="1" class="border-0" style="width:40%;">  <?php
                                  $customer_id=$_GET['id'];
                $sql = "SELECT * FROM customers WHERE id=$customer_id";
                        // $sql = "select * from customers order by customer_name";
                                            $result = mysqli_query($conn, $sql);
                                            while ($row4 = mysqli_fetch_assoc($result)) {
                                                ?> 
             <h4><b>Customer Details:</b></h4>
             <strong id="customer_name"><?php echo $row4['customer_name']; ?></strong>
 
<div id="customer_address"><?php echo $row4['customer_address']; ?></div>
 <div id="phone">Phone: <?php echo $row4['number']; ?></div>
 <div id="phone">GSTIN: <?php echo $row4['tin_no']; ?></div>
 <?php } ?></th>  
                                                                  
                                                                <th colspan="1" class="border-0" style="width:40%;"> <div class="light">
                  <strong>Bill No:<input type="text"></strong> <br/>
  <span> Date:<?php echo $date = date('d/m/Y');  ?></span>
                                                </div></th>
                                               
                                                            </tr>
                                                             
                                                            
                                                        </tbody>
                                                    </table>
                                                                                           
                                            </div>

                                          
                                             
                                                                                      
                                            
                                                                                    
                                        </div>
                                        </div>
       
         
          
  
 
              </div>
              </span>
              
                 
   <div class="box-body">
   <?php
                                  $customer_id=$_GET['id'];
                $sql = "SELECT * FROM customers WHERE id=$customer_id";
                        // $sql = "select * from customers order by customer_name";
                                            $result = mysqli_query($conn, $sql);
                                            while ($row4 = mysqli_fetch_assoc($result)) {
                                                ?> 
  
                          <div class="container">
  <div class="card">

<div class="card-body">
<div class="row mb-12">
<div class="col-sm-4">
 
<div class="col-sm-4">
</div>
<div class="col-sm-4">
 
<div>
<form method="post" action="" enctype="multipart/form-data" id="userForm">
 
</div>
 
 
</div>

 

</div>

<div class="table-responsive-sm">
<table class="table table-striped">
<thead>
<tr>
<th class="center">#</th>
<th>Item</th>
<th>HSN code</th>
<th>Qty</th>
<th>Rate</th>
<th>MRP</th>
 <th>CGST%</th>
<th>CGST Amt</th>
<th>SGST%</th>
<th>SGST Amt</th>
<th>Amount</th>
</tr>
</thead>
<tbody>
        <?php
                        if(($_SESSION['user_type']=="admin")){
                            $sql = "select * from food_items where food_items.status='1'";
                        }
                        $result = mysqli_query($conn, $sql);
                        $i=1;$total_tax_amount=0;$total_without_tax_amount=0;$total_qty=0; $total_sgst_tax_amount=0; $total_cgst_tax_amount=0;foreach ($result as $row1) { 
							
                            ?>
<tr>
                              
                            <td class="center"><?php echo $i++; ?></td>
                         
 <td class="left strong" id="item_name"><?php echo $row1['item_name']; ?> </td>
<td class="left" id="hsn_code"><?php echo $row1['hsn_code']; ?></td>

<td class="right" id="qty"><?php echo $total_q=$row1['qty']; ?></td>
  <td class="center" id="rate"><?php echo $row1['rate']; ?></td>
<td class="right" id="total"><?php  echo $row1['mrp'] ?></td>
 <?php $total=($row1['qty']*$row1['rate']); $total_without_tax_amount+=$total; 
 $total_q=$row1['qty'];$total_qty+= $total_q;
 ?>  
  
<?php
                                            $sql = "select * from foods";
                                            $result = mysqli_query($conn, $sql);
                                            while ($row5 = mysqli_fetch_assoc($result)) {
                                                ?>  <?php if($row5['id']==$row1['food_id']){ ?>
                                                <?php if($row5['gst_percentage']==12){?>
                                              <td class="right" id="12_sgst"><?php echo $sgst=($row5['gst_percentage']/2); ?> %
                                              <?php }?>
                                               <?php if($row5['gst_percentage']==5){?>
                                              <td class="right" id="5_sgst"><?php echo $sgst=($row5['gst_percentage']/2); ?> %
                                              <?php }?>
                                               <td class="right"  id="sgst_total"><?php echo $sgst_total=(($sgst/100)*$total); ?>
                                               
                                               <?php $total_sgst_tax_amount+=$sgst_total;?>  
                                                <?php if($row5['gst_percentage']==12){?>
                                                <td class="right" id="12_cgst"><?php echo $cgst=($row5['gst_percentage']/2); ?> %
                                               <?php }?>
                                                <?php if($row5['gst_percentage']==5){?>
                                                <td class="right" id="5_cgst"><?php echo $cgst=($row5['gst_percentage']/2); ?> %
                                               <?php }?>
                                               <td class="right" id="cgst_total"><?php echo $cgst_total=(($cgst/100)*$total); ?>
                                                <?php $total_cgst_tax_amount+=$cgst_total;?>  
                                               <td class="right" id="total_amount"><?php echo $total_amount=($total); ?>
                                         <?php $total_amt=($sgst_total+$cgst_total+$total); $total_tax_amount+=$total_amt;?>     
                                            </td>
                                           
       <?php } }} ?> 
       
</tr>
 <tr><td class="left strong"><b>Total Qty </b> </td> <td class="left" id="hsn_code"></td> <td class="left" id="hsn_code"></td> <td class="left" id="hsn_code"><?php echo $total_qty; ?></td></tr> 
 
 
</tbody>
</table>
</div>
<div class="row">
<div class="col-lg-4 col-sm-5">
    
 
 
 
 
 
</div>
<div class="col-lg-4 col-sm-5">

</div>
<br/><br/><br/><br/> 

<div class="col-lg-4 col-sm-5 ml-auto">
<table class="table table-clear">
<tbody>
 
<tr>
<td class="left">
<strong>GROSS AMOUNT</strong>
</td>
<td class="right" id="total_without_tax_amount"><?php echo $total_without_tax_amount;?> </td>
</tr>
<!--<tr>
<td class="left">
<strong>Discount (20%)</strong>
</td>
<td class="right">$1,699,40</td>
</tr>-->
<tr>
<td class="left">
 <strong>ADD SGST</strong>
</td>
<td class="right" id="total_sgst_tax_amount"> <?php echo $total_sgst_tax_amount;?>  </td>
</tr>
<tr>
<td class="left">
 <strong>ADD CGST</strong>
</td>
<td class="right" id="total_cgst_tax_amount"> <?php echo $total_cgst_tax_amount;?>  </td>
</tr>
<?php /*?><tr>
<td class="left">
 <strong>TOTAL GST</strong>
</td>
<td class="right"><?php echo $total_cgst_tax_amount=($total_sgst_tax_amount+$total_cgst_tax_amount);?></td>
</tr><?php */?>
<tr>
<td class="left">
<strong>NET AMOUNT</strong>
</td>
<td class="right">
<strong id="total_tax_amount"> <?php echo  round($total_tax_amount);?></strong>
</td>
</tr>
</tbody>
</table>
<?php }?>
</div>

</div>

</div>
</div>
</div>
									<!-- /.box -->
 </div>
            </div>
          
          <!-- /.box -->
        </div>
        <!-- /.col -->
   
        <div class="float-right d-print-none">
                                                    <a href="javascript:window.print()" class="btn btn-info text-light"><i class="fa fa-print"></i></a>
                                                    
                                                </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  </form>
      <?php include "footer.php"; ?>

  <!-- Control Sidebar -->
     
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>


<script>
$(document).ready(function(){
    $('#userForm').submit(function(){
     
        // show that something is loading
        $('#response').html("<b>Loading response...</b>");
         
        /*
         * 'post_receiver.php' - where you will pass the form data
         * $(this).serialize() - to easily read form data
         * function(data){... - data contains the response from post_receiver.php
         */
        $.ajax({
            type: 'POST',
            url: 'invoice.php', 
            data: $(this).serialize()
        })
        .done(function(data){
             
            // show the response
            $('#response').html(data);
             
        })
        .fail(function() {
         
            // just in case posting your form failed
            alert( "Posting failed." );
             
        });
 
        // to prevent refreshing the whole page page
        return false;
 
    });
});
</script>
</body>
</html>
<script>
function myPrint() {
    window.print();
}
</script>