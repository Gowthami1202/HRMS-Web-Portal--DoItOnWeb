<?php
session_start();
$page = "Customers";
include "timeout.php";
include "config.php";
if (($_SESSION['user_type'] != "admin"))  header("location: index.php");
$msg = "";
$msg_color = "";
$customer_name="";
if (isset($_POST['submit'])) {
	   
   $created_date = date('y/m/d');   
    $customer_name = trim($_POST['customer_name']);
	$customer_type = trim($_POST['customer_type']);
	$customer_address = trim($_POST['customer_address']);
	$number = trim($_POST['number']);
	$tin_no = trim($_POST['tin_no']);
	
	  $sql = "SELECT * FROM customers WHERE trim(customer_name)='$customer_name'";
    $result = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($result);
   if ($count >= 1) {
        $msg = "Customers  already in use";
        $msg_color = "red";
    } else {
        $msg_color = "green";
        if($_SESSION['user_type']=="admin") {
            $msg = "Customers added successfully";
        }else{
            $msg = "Customers added successfully";
        }

        $stmt = $conn->prepare("INSERT INTO customers (customer_name,customer_type,customer_address,number,tin_no,created_date) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssssss",$customer_name,$customer_type,$customer_address,$number,$tin_no,$created_date);
        $stmt->execute();
		$id = $stmt->insert_id;
       
        header("location: customers.php");
    
}}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title> View Customers</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/dataTables.responsive.css">
<script src="css/dataTables.responsive.js"></script>
  <link rel="stylesheet" href="css/dataTables.responsive.scss">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

 

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

     <?php include "header.php"; ?>

    <?php include "menu.php"; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content">
      <div class="row">

				 <div class="col-xs-12">
				
		                   <div class="login-panel panel panel-default">

						<div class="table-responsive">
       <div class="box-header">
             <center> <h3>Customers Type List</h3> </center>
           <hr>
             <h3>   <a href="add-customers.php" class="btn btn-info"> <b>Add Customers</b></a></h3>
            </div>
   <div class="box-body">
                         <table id="example1" class="table table-bordered table-striped">
                    <thead>
                         <tr style="background-color: #2a6b90;color:white">
                            <th>Customer Name</th>
                            <th>Customer Type</th>
                            <th  width="120px">Action</th>
                            
                                        </tr>
                                    </thead>
                                       <tbody>
                        <?php
                        if(($_SESSION['user_type']=="admin")){
                            $sql = "select * from customers";
                        }
                        $result = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($result)) {
                            ?>
                            <tr> 
                                 <td><?php echo $row['customer_name']; ?></td>
                                 <td><?php echo $row['customer_type']; ?></td>
                                <td> <a class="btn btn-info fa fa-print" href="invoice.php?id=<?php echo $row['id']; ?>"></a>
                                <a class="btn btn-info fa fa-eye" href="#"></a> <a class="btn btn-info fa fa-edit" href="edit-customers.php?id=<?php echo $row['id']; ?>"></a>
                                <a class="btn btn-info fa fa-trash-o" href="delete-customers.php?id=<?php echo $row['id']; ?>"></a></td>
                            </tr>
                        <?php

                        }
                        ?>
                        </tbody>
                                        </tbody>
									</table>
									<!-- /.box -->
 </div>
            </div>
          
          <!-- /.box -->
        </div>
        <!-- /.col -->
     
 
        
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
      <?php include "footer.php"; ?>

  <!-- Control Sidebar -->
     
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
</body>
</html>
