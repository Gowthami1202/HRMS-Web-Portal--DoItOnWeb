<?php
    date_default_timezone_set("Asia/Kolkata");

    $mysql_hostname = "localhost";
    $mysql_user = "u301951874_chogolate";
    $mysql_password = "8m!2KNg6~tHC";
    $mysql_database = "u301951874_mittai";

    
    $conn = new mysqli($mysql_hostname, $mysql_user, $mysql_password, $mysql_database);
