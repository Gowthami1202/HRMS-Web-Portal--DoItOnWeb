<?php

 $user_id=$_SESSION['user_id'];
 ?>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <ul class="sidebar-menu" data-widget="tree">

               <li class="<?php if($page=="Dashboard") echo "active"; ?>"><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
			   <ul class="treeview  <?php if($page1=="Dashboard1") echo "active"; ?>">
			     </ul>
</li>
 
	  <?php if(($_SESSION['user_type']=="admin") || ($_SESSION['user_type']=="accounts")) { ?>
          <li class="treeview <?php if($page=="aaaaaa") echo "active"; ?>">
          <a href="#">
            <i class="fa fa-inr"></i>
            <span>Accounts</span>
            <span class="pull-right-container">
              <span class="fa fa-angle-left pull-right"></span>
            </span>
          </a>
          <ul class="treeview-menu">
		  <!--<li><a href="billing.php"><i class="fa fa-circle-o text-aqua "></i>Billing</a></li>-->
		  <?php if($_SESSION['user_type']=="accounts") { ?>
		  <li <?php if($page1=="Billing Record") echo "class='active'"; ?>><a href="billing-record.php"><i class="fa fa-circle-o text-aqua "></i>Billing Details</a></li>
          <?php } ?>
           <?php if(($_SESSION['user_type']=="admin")) { ?>

             <li <?php if($page=="Foods") echo "class='active'"; ?>><a href="foods.php"><i class="fa fa-circle-o text-aqua"></i>Food Fees</a></li>
              <li <?php if($page=="addFoodItems") echo "class='active'"; ?>><a href="food-items.php"><i class="fa fa-circle-o text-red"></i>Food Items</a></li>
            <li <?php if($page=="Customers") echo "class='active'"; ?>><a href="customers.php"><i class="fa fa-circle-o text-red"></i>Customer</a></li> 
              <li <?php if($page=="View Yearly Fees Details") echo "class='active'"; ?>><a href="view_yearly_fees_details.php"><i class="fa fa-circle-o text-red"></i>Add Yearly Fees</a></li>
           </ul>
        </li>
            <?php } } ?>
		 
        
         
      

           
       
         
       
     
        
               
          <li class="treeview active">
          
          <ul class="treeview-menu">
             <li><a href="my-profile.php"><i class="fa fa-circle-o text-aqua"></i>My Profile</a></li>
           </ul>
        </li>
        
          <li class="treeview active">
          
          <ul class="treeview-menu">
             <li><a href="change-password.php"><i class="fa fa-circle-o text-aqua"></i>Change Password</a></li>
           </ul>
        </li>
            
      </ul>
	  
    </section>
    <!-- /.sidebar -->
  </aside>