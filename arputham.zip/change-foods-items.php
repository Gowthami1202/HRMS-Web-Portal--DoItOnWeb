<?php
 session_start();
 include "timeout.php";
include "config.php";
if (($_SESSION['user_type'] != "admin")) header("location: index.php");

$id =  $_GET['id'];
$status =  $_GET['status'];
 if($status==1)
{
	 $stmt = $conn->prepare("UPDATE food_items  set status=? where id=?");
        $stmt->bind_param("ss",$status,$id);
        $stmt->execute();
       
      
 }
elseif($status==0)
{
 $stmt = $conn->prepare("UPDATE food_items  set status=? where id=?");
        $stmt->bind_param("ss",$status,$id);
        $stmt->execute();
    }
header("Location:food-items.php");
  mysqli_close($stmt);
 ?> 