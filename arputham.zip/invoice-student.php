<?php
session_start();
$page = "invoice-student";
include "timeout.php";
include "config.php";
if (($_SESSION['user_type'] != "admin") && ($_SESSION['user_type'] != "principal") && ($_SESSION['user_type'] != "staff") && 
($_SESSION['user_type'] != "student")  && ($_SESSION['user_type'] != "accounts")) header("location: index.php");
 $id = $_GET['id'];
$user_id=$_SESSION['user_id'];
$sql = "select * from students where id=$id";
$result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
 $msg = "";

$msg_color = "";
$admission_no ="";
$username = "";
$standard ="";
$created_date="";
$monthly_fees="";
$monthlyamount="";
$qauntity="";
$monthly_price="";
$monthly_paid="";
$yearly_fees_name="";
$yearly_fees_cost="";
$yearlyqauntity="";
$yearly_price="";
$yearlypaid="";
$yearlyunpaid="";
$monthly_unpaid="";
$date = date('y/m/d');

if($_POST)
 {
         $admission_no = trim($_POST['admission_no']);
         $username = trim($_POST['username']);
         $standard= trim($_POST['standard']);
         $monthly_fees = trim($_POST['monthly_fees']);
         $monthlyamount = trim($_POST['monthlyamount']);
         $qauntity = trim($_POST['qauntity']);
         $monthly_price = trim($_POST['monthly_price']);
         $monthly_paid = trim($_POST['monthly_paid']);
         $yearly_fees_name = trim($_POST['yearly_fees_name']);
         $yearly_fees_cost = trim($_POST['yearly_fees_cost']);
         $yearlyqauntity = trim($_POST['yearlyqauntity']);
         $yearly_price = trim($_POST['yearly_price']);
         $yearlypaid = trim($_POST['yearlypaid']);
         $yearlyunpaid = trim($_POST['yearlyunpaid']);
         $monthly_unpaid = trim($_POST['monthly_unpaid']);
		 $created_date = trim($_POST['created_date']);
        	
		 $stmt = $conn->prepare("INSERT INTO student_fees (admission_no,username,standard,monthly_fees,monthlyamount,qauntity,monthly_price,monthly_paid,yearly_fees_name,yearly_fees_cost,yearlyqauntity,yearly_price,yearlypaid,yearlyunpaid,monthly_unpaid,created_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        $stmt->bind_param("ssssssssssssssss", $admission_no,$username, $monthly_fees,$monthlyamount, $qauntity,$monthly_price,$monthly_paid,$yearly_fees_name,$yearly_fees_cost,$yearlyqauntity,$yearly_price,$yearlyunpaid,$monthly_unpaid,$created_date,$id);

        $stmt->execute() or die ($stmt->error);
		
		//$stmt = $conn->prepare("INSERT INTO student_record (full_name,email,status,password,mobile,photo) VALUES (?,?,?,?,?,?)");

        //$stmt->bind_param("ssssss", $full_name,$email,$status, $password,$mobile,$photo);

        //$stmt->execute() or die ($stmt->error);

        $id=$stmt->insert_id;
 
}
 ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Edit Student Record</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/dataTables.responsive.css">
<script src="css/dataTables.responsive.js"></script>
  <link rel="stylesheet" href="css/dataTables.responsive.scss">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

	<link rel='stylesheet' type='text/css' href='css/style.css' />
	<link rel='stylesheet' type='text/css' href='css/print.css' media="print" />
	<script type='text/javascript' src='js/jquery-1.3.2.min.js'></script>
	<script type='text/javascript' src='js/example.js'></script>

  
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        <link rel="stylesheet" href="css/jquery.datepicker.css">
</head>
<body>
	 
				
 
<form method="post" name="form">
 <div id="page-wrap">

		<textarea id="header">INVOICE</textarea>
		
		<div id="identity">
<img id="image" src="photo/logo.jpg"  width="100"alt="logo" /> <b style="color: red;font-size: 30px;padding: 16px;">HILLEYA MATRICULATION SCHOOL</b>
 <br/>
   		</div>
		
		<div style="clear:both"></div>
		
		<div id="customer">

          
 
            <table id="meta">
                <tr>
                    <td class="meta-head">Admission No #</td>
                    <td><textarea id="admission_no" name"admission_no" value="<?php echo $row['admission_no']; ?>"><?php echo $row['admission_no']; ?></textarea></td>
                </tr>
                <tr>

                    <td class="meta-head">Student Name</td>
                    <td><textarea id="user_name" name"user_name" value="<?php echo $row['first_name']; ?> <?php echo $row['last_name']; ?>"><?php echo $row['first_name']; ?> <?php echo $row['last_name']; ?></textarea></td>
                </tr>
                 <tr>

                    <td class="meta-head">Class & Section</td>
                    <td><?php $sql2 = "select * from class"; $result2 = mysqli_query($conn, $sql2);
					while ($row2 = mysqli_fetch_assoc($result2)) 
if($row['class_id']==$row2['id']){?><textarea id="standard" name"standard" value="<?php echo $row2['standard']; ?> <?php echo $row2['section_name']; ?>"> <?php echo $row2['standard']; ?> <?php echo $row2['section_name']; ?> 
<?php }?></textarea></td>
                </tr>
                 <tr>

                    <td class="meta-head">Date</td>
                    <td><textarea id="created_date" value="<?php echo date($row['created_date']); ?>"><?php echo date($row['created_date']); ?></textarea></td>
                </tr>
                

            </table>
		
		</div>
		
		<table id="items">
		
		  <tr>
		      <th>Fees</th>
		      <th>Description</th>
		      <th>Fees Cost</th>
		      <th>Monthly / Yearly</th>
		      <th>Price</th>
              <th>Paid /UnPaid</th>
 		  </tr>
           <?php 
							   $sql2 = "select * from fees_detail";
							  $result2 = mysqli_query($conn, $sql2);
							  $i=1;
                        while ($row2 = mysqli_fetch_assoc($result2)) {?>
					
		   <tr class="item-row">
		     <?php if($row['class_id']==$row2['class_id']){?> <td class="item-name"><div class="delete-wpr">
              	 <?php  $sql3 = "select * from fees";
							  $result3 = mysqli_query($conn, $sql3);
                        while ($row3 = mysqli_fetch_assoc($result3)) {?>
					<?php if($row2['fees_id']==$row3['id']){?>
                <textarea name="monthly_fees" id="monthly_fees" value="<?php echo $row3['fees_name']; ?>"> <?php echo $row3['fees_name']; ?>
  </textarea><a class="delete" href="javascript:;" title="Remove row">X</a></div></td><?php } }}?>
<?php if($row['class_id']==$row2['class_id']){?>
		      <td class="description">Monthly Base Paid</td>
		      <td><textarea class="cost" id="monthlyamount" name"monthlyamount" value="<?php echo $cost=$row2['amount']; ?>"><?php echo $cost=$row2['amount']; ?> </textarea></td>
		      <td><select class="qty" id="qauntity<?php echo $i; ?>">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
  <option value="6">6</option>
  <option value="7">7</option>
  <option value="8">8</option>
  <option value="9">9</option>
  <option value="10">10</option>
  <option value="11">11</option>
  <option value="12">12</option>
     <option value="0" selected>0</option>
</select> </td>
		      <td><span class="price" name="monthly_price" id="monthly_price" value="<?php echo $cost; ?>"> <?php echo $cost; ?></span></td>
                 <td class="description"><select name="monthly_unpaid" id="unpaid<?php echo $i; ?>">
  <option  value="paid">paid</option>
    <option  value="Unpaid" selected>Unpaid</option>
</select>

<select name="monthly_paid" id="paid<?php echo $i;?>">
  <option value="paid" selected>paid</option>
    <option value="Unpaid">Unpaid</option>
</select>
</td> 
 		  </tr>
          
              <script type="text/javascript">
  $('#paid<?php echo $i; ?>').hide();
   $('#qauntity<?php echo $i; ?>').change(function(){
var unpaid =$('#unpaid<?php echo $i; ?>');
var paid = $('#paid<?php echo $i; ?>');
     
var select   = $('#qauntity<?php echo $i; ?>').val();

if (select == 0){
  unpaid.show();
  paid.hide();
}
if (select == 1){
  paid.show();
   unpaid.hide();
}
if (select == 2){
  paid.show();
   unpaid.hide();
}
if (select == 3){
  paid.show();
   unpaid.hide();
}
if (select == 4){
  paid.show();
   unpaid.hide();
}
if (select == 5){
  paid.show();
   unpaid.hide();
}
if (select == 6){
  paid.show();
   unpaid.hide();
}
if (select == 7){
  paid.show();
   unpaid.hide();
}
if (select == 8){
  paid.show();
   unpaid.hide();
}
if (select == 9){
  paid.show();
   unpaid.hide();
}if (select == 10){
  paid.show();
   unpaid.hide();
}
if (select == 11){
  paid.show();
   unpaid.hide();
}
if (select == 12){
  paid.show();
   unpaid.hide();
}
    });
	</script>
          <?php $i++; } } ?>
         
           <?php  		   $sql2 = "select * from yearly_fees_detail";
							  $result2 = mysqli_query($conn, $sql2);
							  $i = 1;
                        while ($row2 = mysqli_fetch_assoc($result2)) {?>
					
		   <tr class="item-row">
		     <?php if($row['class_id']==$row2['class_id']){?> <td class="item-name"><div class="delete-wpr">
              	 <?php  $sql3 = "select * from fees";
							  $result3 = mysqli_query($conn, $sql3);
                        while ($row3 = mysqli_fetch_assoc($result3)) {?>
					<?php if($row2['fees_id']==$row3['id']){?>
                    <textarea name="yearly_fees_name" id="yearly_fees_name" value="<?php echo $row3['fees_name']; ?>">
               <?php echo $row3['fees_name']; ?> 
  </textarea><a class="delete" href="javascript:;" title="Remove row">X</a></div></td><?php } }}?>
<?php if($row['class_id']==$row2['class_id']){?>
		      <td class="description"><textarea>Yearly Base Paid</textarea></td>
		      <td><textarea class="cost" name="yearly_fees_cost" id="yearly_fees_cost" value="<?php echo $cost=$row2['amount']; ?>"> <?php echo $cost=$row2['amount']; ?></textarea></td>
		      <td><select class="qty" name="yearlyqauntity"  id="yearlyqauntity<?php echo $i;?>" data-value="<?php echo $i;?>">
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
  <option value="6">6</option>
  <option value="7">7</option>
  <option value="8">8</option>
  <option value="9">9</option>
  <option value="10">10</option>
  <option value="11">11</option>
  <option value="12">12</option>
     <option value="0" selected>0</option>
</select> </td>
		      <td><span class="price" name="yearly_price" id="yearly_price" value="<?php echo $cost; ?>"> <?php echo $cost; ?></span></td>
                <td class="description"><select id="yearlyunpaid<?php echo $i;?>" name="yearlyunpaid">
  <option value="paid">paid</option>
    <option value="Unpaid" selected>Unpaid</option>
</select>

<select id="yearlypaid<?php echo $i;?>" name="yearlypaid">
  <option value="paid" selected>paid</option>
    <option value="Unpaid">Unpaid</option>
</select>
</td> 
  		  </tr>
          <script type="text/javascript">
  $('#yearlypaid<?php echo $i;?>').hide();
 
	 $('#yearlyqauntity<?php echo $i;?>').change(function(){
var yearlyunpaid =$('#yearlyunpaid<?php echo $i;?>');
var yearlypaid =$('#yearlypaid<?php echo $i;?>');
 
    yearlypaid=$('#yearlypaid<?php echo $i;?>').hide();
var select   = $('#yearlyqauntity<?php echo $i;?>').val();
 
if (select == 0){
  yearlyunpaid.show();
  yearlypaid.hide();
}
if (select == 1){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 2){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 3){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 4){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 5){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 6){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 7){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 8){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 9){
  yearlypaid.show();
   yearlyunpaid.hide();
}if (select == 10){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 11){
  yearlypaid.show();
   yearlyunpaid.hide();
}
if (select == 12){
  yearlypaid.show();
   yearlyunpaid.hide();
}
    });
	</script>
      
          <?php    $i++;} } ?>
         
           
		  
		  <tr id="hiderow">
		    <td colspan="6"><a id="addrow" href="javascript:;" title="Add a row">Add a row</a></td>
		  </tr>
		  
	 
		  <tr>
 		      <td colspan="3" class="blank"> </td>
		      <td colspan="2" class="total-line">Total</td>
		      <td class="total-value" name="total-value" value="total-value"><div id="total"> </div></td>
		  </tr>
		  <tr>
		      <td colspan="3" class="blank"> </td>
		      <td colspan="2" class="total-line">Amount Paid</td>

		      <td class="total-value"><textarea id="paid"></textarea></td>
		  </tr>
		  <tr>
		      <td colspan="3" class="blank"> </td>
		      <td colspan="2" class="total-line balance">Balance Due</td>
		      <td class="total-value balance"><div class="due"></div></td>
		  </tr>
		
		</table>
		
		<div id="terms">
		  <h5>Terms</h5>
		  <textarea>NET 30 Days. Finance Charge of 1.5% will be made on unpaid balances after 30 days.</textarea>
		</div>
	                  <a href="billing-record.php" class="btn btn-info"> <b>Back</b></a>  
                      <input class="btn btn-info" id="submit" type="submit" value="Pay"/>
                    <a href="billing-record.php" class="btn btn-info" id="print" onclick="myPrint()" style="display:none;"> <b>Pay</b></a> 
 

	</div>
      </form>
</body>
</html>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/
libs/jquery/1.3.0/jquery.min.js">
</script>

<script type="text/javascript" >
$("#submit").click(function(e) {
  e.preventDefault();
var admission_no = $("#admission_no").val();
 
var username = $("#username").val();
var standard =$("#standard").val();
var created_date=$("#created_date").val();
var monthly_fees=$("#monthly_fees").val();
var monthlyamount=$("#monthlyamount").val();
var qauntity=$("#qauntity").val();
var monthly_price=$("#monthly_price").val();
var monthly_paid=$("#monthly_paid").val();
var yearly_fees_name=$("#yearly_fees_name").val();
var yearly_fees_cost=$("#yearly_fees_cost").val();
var yearlyqauntity=$("#yearlyqauntity").val();
var yearly_price=$("#yearly_price").val();
var yearlypaid=$("#yearlypaid").val();
var yearlyunpaid=$("#yearlyunpaid").val();
var monthly_unpaid=$("#monthly_unpaid").val();
 
 var dataString = '&admission_no='+ admission_no + '&username=' + username + '&standard=' + standard + '&created_date=' + created_date
 +'&monthly_fees=' + monthly_fees+'&monthlyamount=' + monthlyamount+'&qauntity=' + qauntity + '&monthly_price=' + monthly_price+ '&monthly_paid=' + monthly_paid+'&yearly_fees_name=' + yearly_fees_name+ '&yearlyqauntity=' + yearlyqauntity+ '&yearly_price='+ yearly_price+ '&yearlypaid='+yearlypaid+'&yearlyunpaid='+yearlyunpaid+'&monthly_unpaid='+yearlyunpaid;

if(admission_no=='' || username=='' || password=='' || gender=='')
{
$('.success').fadeOut(200).hide();
$('.error').fadeOut(200).show();
}
else
{
$.ajax({
type: "POST",
url: "invoice-student.php",
data: dataString,
success: function(){
$('#print').fadeIn(200).show();
$('.error').fadeOut(200).hide();
}
});
}
return false;
});
 
</script>

<script>
function myPrint() {
    window.print();
}
</script>